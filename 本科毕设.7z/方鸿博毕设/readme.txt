《图像随机值脉冲噪声的去除》

test8.m为毕设的matlab代码